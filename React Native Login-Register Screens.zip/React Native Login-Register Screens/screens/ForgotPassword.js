import * as WebBrowser from 'expo-web-browser';
import * as React from 'react';
import { Image, Platform, StyleSheet, Text, TouchableOpacity, View, SafeAreaView, StatusBar, Dimensions, Button, TextInput } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Feather, Ionicons } from 'react-native-vector-icons';
import { primaryColor } from '../constants/Colors';
const { width, height } = Dimensions.get('window');
//const LoginImage = require('../assets/images/8Q-zGQuK.jpg');
const LoginImage = 'http://localhost/imgh/8Q-zGQuK.jpg';
const ImageDimens = {
  width: width / 3,
  height: width / 3
}
export default class ForgotPassword extends React.Component {
  constructor(props) {
    super(props)
    this.state = {

    }
  }
  render() {
    return (

      <SafeAreaView style={{ backgroundColor: '#EBECF4f', flex:1 }}>
        <View style={styles.header}>
          <View>
            <TouchableOpacity onPress={() => this.props.navigation.goBack()}>
              <Feather name="arrow-left" style={styles.backIcon} />
            </TouchableOpacity>
          </View>
          {/* <View>
            <TouchableOpacity onPress={() => this.props.navigation.navigate('Login')}>
              <Text style={styles.signUp}>Sign up</Text>
            </TouchableOpacity>
          </View> */}
        </View>
        <ScrollView>
        <View style={styles.container}>
          <View>
            <Text style={styles.title}>Forgot Password</Text>
          </View>
          <View style={styles.textInputWrapper}>
            <View>
              <TextInput placeholder="Enter your email address" textContentType="emailAddress" style={styles.textInput} />
            </View>
            <TouchableOpacity><Text style={styles.loginButton}>Recover Password</Text></TouchableOpacity>
          </View>
        </View>
        </ScrollView>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 15
  },
  signUp: {
    fontWeight: '700',
    fontSize: 18
  },
  backIcon: {
    color: primaryColor,
    fontSize: 24
  },
  container: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-between',
    flex: 1
    // backgroundColor: '#fff',
    //height:100
  },
  title: {
    fontWeight: '700',
    fontSize: 30,
    paddingTop: 30,
    paddingBottom: 50
  },
  textInputWrapper: {
    paddingVertical: 20
  },
  textInput: {
    width: width - 50,
    paddingLeft: 18,
    paddingTop:18,
    paddingBottom:18,
    paddingRight:90,
    marginVertical: 7,
    borderWidth: 0,
    borderRadius: 50,
    //borderColor: "#276cf2",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4
    },
    shadowRadius: 5.46,
    shadowOpacity: 0.32,
    elevation: 19,
    fontSize: 16,
    //fontWeight:'700',
    backgroundColor: '#fff'
  },
  forgotPassword: {
    color: primaryColor,
    fontWeight:'700',
    fontSize:16,
    position:'absolute',
    bottom:25,
    right:25
  },
  imageWrapper: {
    borderRadius: 100,
    borderColor: '#fff',
    borderWidth: 3,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.32,
    shadowRadius: 5.46,
    elevation: 19,
    marginBottom: 50
  },
  image: {
    borderRadius: 100,
    width: width / 3,
    height: width / 3,
    borderColor: '#fff',
    borderWidth: 3,
  },
  loginButton: {
    width: width - 50,
    padding: 10,
    marginVertical: 15,
    borderWidth: 0,
    borderRadius: 50,
    borderColor: "#fff",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4
    },
    shadowRadius: 5.46,
    shadowOpacity: 0.32,
    elevation: 19,
    fontSize: 20,
    fontWeight: '700',
    backgroundColor: primaryColor,
    color: '#fff',
    textAlign: 'center'
  },
  registerButton: {
    width: width - 50,
    padding: 15,
    marginVertical: 20,
    fontSize: 20,
    fontWeight: '700',
    //backgroundColor: '#fff',
    color: '#000',
    textAlign: 'center'
  }

});
