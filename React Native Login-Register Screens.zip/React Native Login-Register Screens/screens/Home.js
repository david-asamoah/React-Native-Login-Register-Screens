import * as WebBrowser from 'expo-web-browser';
import * as React from 'react';
import { Image, Platform, StyleSheet, Text, TouchableOpacity, View, SafeAreaView, StatusBar, Dimensions, Button, TextInput, ImageBackground } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Feather, Ionicons } from 'react-native-vector-icons';
import { primaryColor } from '../constants/Colors';
const { width, height } = Dimensions.get('window');
//const LoginImage = require('../assets/images/8Q-zGQuK.jpg');
const LoginImage = 'http://localhost/imgh/8Q-zGQuK.jpg';
const bg = require('../assets/images/bg.png')
const ImageDimens = {
  width: width / 3,
  height: width / 3
}
export default class Home extends React.Component {
  constructor(props) {
    super(props)
    this.state = {

    }
  }
  render() {
    return (
      <SafeAreaView style={{ backgroundColor: primaryColor, flex:1 }}>
         <StatusBar backgroundColor={primaryColor} />
        <Image source={bg} style={styles.background} resizeMode="cover" />
        <View style={styles.container}>
          <Text style={styles.title}>Find People &</Text>
          <Text style={styles.title}>Be Social</Text>
          <Text style={[styles.subtitle, { paddingTop: 20 }]}>Find all your friends</Text>
          <Text style={styles.subtitle}>in once place by signing up</Text>
          <TouchableOpacity onPress={() => this.props.navigation.navigate('Login')}>
            <Text style={styles.loginButton}>Login</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => this.props.navigation.navigate('Register')}>
            <Text style={styles.register}>Register</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }
}
const styles = StyleSheet.create({
  background: {
    width: width,
    height: height
  },
  container: {
    position: 'absolute',
    top: height - 350,
    width: width,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#fff'
  },
  subtitle: {
    color: '#f2f2f2'
  },
  loginButton: {
    width: width - 50,
    padding: 10,
    marginVertical: 25,
    borderWidth: 0,
    borderRadius: 50,
    borderColor: "#fff",
    // shadowColor: "#000",
    // shadowOffset: {
    //   width: 0,
    //   height: 4
    // },
    // shadowRadius: 5.46,
    // shadowOpacity: 0.32,
    // elevation: 19,
    fontSize: 20,
    fontWeight: '700',
    backgroundColor: '#fff',
    color: '#000',
    textAlign: 'center'
  },
  register: {
    fontWeight: '500',
    fontSize: 16,
    color: '#fff'
  }
});
