


export const primaryColor = '#4ec7a4';

